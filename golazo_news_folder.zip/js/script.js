
const apiKey = '637f4256a03f446c8fd964ca5a7fdc5b';
let allArticles = [];

async function translateText(text) {
  try {
    const res = await fetch('https://libretranslate.de/translate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ q: text, source: 'en', target: 'pt', format: 'text' })
    });
    const data = await res.json();
    return data.translatedText || text;
  } catch (e) {
    return text;
  }
}

async function loadNews(query) {
  const container = document.getElementById('news-section');
  container.innerHTML = '<p style="grid-column: 1/-1; text-align:center">Carregando...</p>';
  try {
    const urls = [
      `https://newsapi.org/v2/everything?q=${query}&language=pt&apiKey=${apiKey}`,
      `https://newsapi.org/v2/everything?q=${query}&language=en&apiKey=${apiKey}`
    ];

    allArticles = [];
    for (const url of urls) {
      const res = await fetch(url);
      const data = await res.json();
      if (data.articles) allArticles.push(...data.articles);
    }

    displayNews(allArticles);
  } catch (error) {
    container.innerHTML = '<p style="grid-column: 1/-1; text-align:center">Erro ao carregar notícias.</p>';
  }
}

async function displayNews(articles) {
  const container = document.getElementById('news-section');
  container.innerHTML = '';
  for (let article of articles.slice(0, 12)) {
    let title = article.title;
    let description = article.description || '';
    if (article.language === 'en' || article.url.includes('/en')) {
      title = await translateText(title);
      description = await translateText(description);
    }
    const div = document.createElement('div');
    div.className = 'news';
    div.innerHTML = `
      <img src="${article.urlToImage || 'https://via.placeholder.com/300'}" alt="imagem da notícia">
      <h2>${title}</h2>
      <p>${description}</p>
      <a href="${article.url}" target="_blank">Leia mais</a>
    `;
    container.appendChild(div);
  }
}

function searchNews() {
  const keyword = document.getElementById('searchInput').value.toLowerCase();
  const filtered = allArticles.filter(article => article.title.toLowerCase().includes(keyword));
  displayNews(filtered);
}

loadNews('brasileirao');
